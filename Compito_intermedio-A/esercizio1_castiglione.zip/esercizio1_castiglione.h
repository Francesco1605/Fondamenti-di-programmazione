#ifndef ESERCIZIO1_CASTIGLIONE_H
#define ESERCIZIO1_CASTIGLIONE_H

// Funzioni per le operazioni matematiche
int add(int a, int b);
int sub(int a, int b);
int mul(int a, int b);
float divi(int a, int b);
int mod(int a, int b);
int power(int base, int exp);

// Funzione per testare tutte le operazioni
void test_all_operations(int arr[], int size);

#endif
