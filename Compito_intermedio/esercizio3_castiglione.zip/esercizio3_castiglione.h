#ifndef ESERCIZIO3_CASTIGLIONE_H
#define ESERCIZIO3_CASTIGLIONE_H

void mask_word(const char* word, char* masked_word);  // Dichiarazione per nascondere la parola
int check_letter(const char* word, char* masked_word, char letter);  // Dichiarazione per verificare la lettera

#endif
